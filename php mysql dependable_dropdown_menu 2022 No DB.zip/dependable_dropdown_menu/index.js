$("#country").change(function(){
    var country_id = $(this).val();
    console.log(country_id);

    // Ajax Syntex
    $.ajax({
        method: "POST",
        url: "subdrop.php",
        data:{country_id:country_id},
        success:function(data){
            $(".subDiv").html(data)

        }

    });
});